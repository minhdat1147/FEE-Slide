var btn = document.querySelector('button');

function random(number) {
  return Math.floor(Math.random()*number);
}

function bgChange() {
  const rndCol = 'rgb(' + random(255) + ',' + random(255) + ',' + random(255) + ')';
  document.body.style.backgroundColor = rndCol;
}

btn.onclick = bgChange;

btn.onfocus = bgChange;
btn.onblur = bgChange;

btn.ondblclick = bgChange;

document.onkeypress = bgChange;

btn.onmouseenter = bgChange;
btn.onmouseout = bgChange;
