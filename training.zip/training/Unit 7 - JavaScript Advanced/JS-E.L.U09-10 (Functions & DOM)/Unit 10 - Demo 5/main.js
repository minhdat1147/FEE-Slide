// get the 1st h1
var h1 = document.querySelector('h1');

// add text to its content
h1.textContent = 'Helo From FA';

// add style to it
h1.style.border = '1px solid black';

// add class it it
h1.classList.add('text-blue')