// take the 1st main
var main = document.getElementsByTagName('main')[0];

main.innerHTML = `
  <p>1st paragraph</p>
  <p class="text-red">2nd paragraph</p>
  <p>3rd paragraph</p>
`