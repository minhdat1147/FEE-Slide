var button = document.getElementsByTagName('button')[0];

// move to botton of the page and click button to scroll top
button.addEventListener('click', function() {
  // demo 1
  // log out current url
  console.log(window.location.href);

  // demo 2
  // navigate to another url
  window.location.href = 'https://google.com';

  // demo 3
  // reload page using JS
  console.log(window.location.reload())

  // demo 4
  window.scrollTo(0, 0);

  // same like above but smoth
  // demo 5
  // window.scrollTo({
  //   top: 0,
  //   left: 0,
  //   behavior: 'smooth'
  // });
});