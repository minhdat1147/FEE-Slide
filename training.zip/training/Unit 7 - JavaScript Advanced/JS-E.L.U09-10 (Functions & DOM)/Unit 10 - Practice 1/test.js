var i = 0;
while (i <= (i + 1)) {/* code */ i++;}