var main = document.getElementsByTagName('main')[0];

main.innerHTML = `
  <h1 class="text-red">Hello from FA</h1>
`