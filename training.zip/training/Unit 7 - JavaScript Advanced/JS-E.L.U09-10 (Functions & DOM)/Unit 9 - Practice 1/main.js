// Practice Call stack:
function sum(a, b) {
  return a + b;
}

function product(a, b) {
  return a * b;
}

function calc() {
  return sum(8, 11) + sum(9, 14);
}

function start() {
  var a = sum(2, 3);
  var b = calc();

  return product(a, b);
}

start();


function loop(i) {
  if (i > 10) {
    return;
  }

  console.log(i);
  loop(i + 1);
}

loop(0);