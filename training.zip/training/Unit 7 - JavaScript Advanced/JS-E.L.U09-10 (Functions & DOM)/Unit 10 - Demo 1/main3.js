window.onload = function () {
  // code only run when document is loadded
  var paragraphs = document.getElementsByTagName('p');

  // access the 2nd paragraph
  console.log(paragraphs[1].textContent);
};



