var paragraphs = document.getElementsByTagName('p');

// access the 2nd paragraph
console.log(paragraphs[1].textContent); 